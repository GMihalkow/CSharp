﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Text;

public class DateModifier
{
    public DateTime startDate;
    public DateTime endDate;
    public TimeSpan remainder;

    public DateTime Parser(string firstDate)
    {
        var date = DateTime.ParseExact(firstDate, "yyyy MM dd", CultureInfo.InstalledUICulture);
        return date;
    }

    public void DaysExcluder(DateTime startDate, DateTime endDate)
    {
        remainder = startDate - endDate;
        Console.WriteLine(Math.Abs(remainder.Days));
    }
}
