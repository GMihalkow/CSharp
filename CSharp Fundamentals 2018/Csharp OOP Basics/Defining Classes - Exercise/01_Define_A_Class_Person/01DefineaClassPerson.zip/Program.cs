﻿using System;


class Program
{
    static void Main(string[] args)
    {
        Person Pesho = new Person();
        Pesho.Age = 20;
        Pesho.Name = "Pesho";

        Person Gosho = new Person();
        Gosho.Age = 19;
        Gosho.Name = "Gosho";
    }
}

