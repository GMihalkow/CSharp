﻿using System;

namespace _02CreatingConstructors
{
    class Program
    {
        static void Main(string[] args)
        {
            Person  Gosho = new Person("Gosho", 19);
        }
    }
}
