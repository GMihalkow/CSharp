﻿using System;
using System.Collections.Generic;
using System.Text;

public class Gem
{
    public int BonusStrength { get; protected set; }
    public int BonusAgility { get; protected set; }
    public int BonusVitality { get; protected set; }
    public int Clarity { get; protected set; }
}