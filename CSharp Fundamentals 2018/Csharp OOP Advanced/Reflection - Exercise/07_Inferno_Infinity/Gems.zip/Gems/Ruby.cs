﻿using System;
using System.Collections.Generic;
using System.Text;

public class Ruby:Gem
{
    public Ruby()
    {
        this.BonusStrength = 7;
        this.BonusAgility = 2;
        this.BonusVitality = 5;
    }
}