﻿using System;
using System.Collections.Generic;
using System.Text;

public class Amethyst : Gem
{
    public Amethyst()
    {
       this.BonusStrength = 2;
       this.BonusAgility = 8;
       this.BonusVitality = 4;
    }
}