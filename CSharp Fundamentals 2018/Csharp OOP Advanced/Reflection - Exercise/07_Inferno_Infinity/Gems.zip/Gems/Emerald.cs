﻿using System;
using System.Collections.Generic;
using System.Text;

public class Emerald : Gem
{
    public Emerald()
    {
        this.BonusStrength = 1;
        this.BonusAgility = 4;
        this.BonusVitality = 9;
    }
}