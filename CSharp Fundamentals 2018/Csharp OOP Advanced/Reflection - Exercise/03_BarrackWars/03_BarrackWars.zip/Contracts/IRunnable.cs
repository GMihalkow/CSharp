﻿public interface IRunnable
{
    void Run();
}